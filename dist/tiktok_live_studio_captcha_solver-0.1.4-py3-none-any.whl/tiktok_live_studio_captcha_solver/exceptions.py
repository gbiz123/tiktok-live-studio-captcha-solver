class TemplateMatchNotFound(Exception):
    pass
